#if false

#include

/*
 * ImageGetter.cpp
 *
 *  Created on: Feb 6, 2016
 *      Author: CougarRobotics
 */

int readImage(char fname[], Image& image)
{
	int i, j;
	int N, M, Q;
	unsigned char *charImage;
	char header [100], *ptr;

	ifstream ifp;
	ifp.open(fname, ios::in | ios::binary);

	if (!ifp) 	//error checking
	{
		cout << "Can't read image: " << fname << endl;
		exit(1);
	}

 // read header

	ifp.getline(header,100,'\n');		//magic number
	if ( (header[0]!=80) || (header[1]!=53) )	  //if not P5
	{
		cout << "Image " << fname << " is not PGM" << endl;
		exit(1);
	}

	ifp.getline(header,100,'\n');
	while(header[0]=='#')		//file name line in file starts with #
		ifp.getline(header,100,'\n');

	M=strtol(header,&ptr,0);	//number of colums
	N=atoi(ptr);			//number of rows

	ifp.getline(header,100,'\n');
	Q=strtol(header,&ptr,0);	//max gray value

	charImage = (unsigned char *) new unsigned char [M*N];	//creates 2D array

	ifp.read( reinterpret_cast<char *>(charImage), (M*N)*sizeof(unsigned char));  //reads in 2D array

	if (ifp.fail())
	{
		cout << "Image " << fname << " has wrong size" << endl;
		exit(1);
	}

	ifp.close();

 // Convert the unsigned characters to integers

	int val;

	for(i=0; i<N; i++)
		for(j=0; j<M; j++)
		{
			val = (int)charImage[i*M+j];
			image.setPixelVal(i, j, val);
		}

	delete [] charImage;

	return (1);
}


#endif
